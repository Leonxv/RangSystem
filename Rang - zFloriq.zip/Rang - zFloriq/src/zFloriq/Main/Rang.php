<?php

namespace zFloriq\Main;

use zFloriq\Group\Group;

use zFloriq\Listeners\PlayerChatListener;
use zFloriq\Listeners\PlayerJoinListener;
use zFloriq\Listeners\PlayerQuitListener;

use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\scheduler\Task;
use pocketmine\Server;
use pocketmine\utils\TextFormat as ZT;
use pocketmine\event\Listener;
use pocketmine\utils\Config;

use pocketmine\command\CommandSender;
use pocketmine\command\Command;

class Rang extends PluginBase implements Listener {
	
	public $prefix = ZT::AQUA . "Groups " . ZT::GRAY . " | ";
	public static $pfad;
	public $config;
	public $attachments = [];
	
	public function onEnable(){
		$this->group = new Group($this);
		
		self::$pfad = "/root/Server/RangSystem/";
		
		@mkdir("/root/Server/");
		@mkdir("/root/Server/RangSystem");
		@mkdir("/root/Server/RangSystem/Players");
		
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getServer()->getPluginManager()->registerEvents(new Group($this), $this);
		
		// Listeners
		$this->getServer()->getPluginManager()->registerEvents(new PlayerChatListener($this), $this);
		$this->getServer()->getPluginManager()->registerEvents(new PlayerJoinListener($this), $this);
		$this->getServer()->getPluginManager()->registerEvents(new PlayerQuitListener($this), $this);
		
		$this->getLogger()->info($this->prefix . ZT::GREEN . "Das RangSystem wurde erfolgreich geladen" . ZT::GRAY . "!");
		
	}
	
	public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
		$name = $sender->getName();
		$playerfile = new Config(Rang::$pfad . "Players/" . strtolower($name) . ".yml", Config::YAML);
		$groupfile = new Config(Rang::$pfad . "Rang.yml", Config::YAML);
		$player = $sender;
		
		if ($command->getName() == "nick" && $sender->hasPermission("nick.set")) {
            if ($playerfile->get("Nick") != "UNNICKED") {
                
				$playerfile->set("Nick", "UNNICKED");
				$playerfile->save();
				$sender->sendMessage($this->prefix . ZT::RED . "Du hast deinen Nick entfernt" . ZT::GRAY . "!");;
				
				$player->setDisplayName((string)$this->group->getNameTag($name));
				$player->setNameTag((string)$this->group->getNameTag($name));
				
            } else {
				
				$nicks = array(
					"nonameofficial",
					"hackerboy134",
					"bwpro112",
					"fighter28",
					"wazdorf",
					"lolinlolhd",
					"phptorm",
					"mynameismarvin",
					"ragehd6",
					"wewrehyped",
					"pascal",
					"lets hacklp",
					"magicintheair",
					"nexofakeyt",
					"rage lp",
					"summon12", 
					"bestnickever", 
					"thebiglove", 
					"thebigboss",
					"saveme saveyou",
					"tntboy", 
					"marciboy", 
					"leleklp2018", 
					"stevilp", 
					"paulderboss 5738",
					"xxtheboss1478xx"
				);
				
				$m = mt_rand(0, count($nicks) - 1);
				
				$nick = $nicks[$m];
				
				$playerfile->set("Nick", $nick);
				$playerfile->save();
				$player->setDisplayName((string)$this->group->getNameTag($name));
				$player->setNameTag((string)$this->group->getNameTag($name));
				
				$sender->sendMessage($this->prefix . ZT::RED . "Du wurdest als" . ZT::GRAY . ": " . $nick . ZT::RED . " genickt.");
				
            }
            
        }
		
		if (strtolower($command->getName()) == "gg") {
			if($sender->isOp()) {
				if(!empty($args[0])) {
				if (strtolower($args[0]) == "set") {
					if (!empty($args[1]) && !empty($args[2])) {
						$targetfile = new Config(Rang::$pfad . "Players/" . strtolower($args[1]) . ".yml", Config::YAML);
						if ($groupfile->exists($args[2])) {
							$targetfile->set("Group", $args[2]);
							$targetfile->save();
							$sender->sendMessage($this->prefix . ZT::RED . "Du hast " . ZT::YELLOW . strtolower($args[1]) . ZT::RED . " den Rang" . ZT::RED . $args[2] . ZT::RED . " gegeben" . ZT::GRAY . "!");
							$target = $this->getServer()->getPlayerExact($args[1]);
							if($target != null) {
								
								$target->setNameTag((string)$this->group->getNameTag($args[1]));
								$target->kick(ZT::GRAY . "Dein Rang wurde geändert zu " . ZT::GRAY . $args[2] ." bitte rejoine!", false);
								
							}
						} else {
							
							$sender->sendMessage($this->prefix . ZT::RED . "Es gibt den Rang " . ZT::YELLOW . $args[2] . ZT::RED . " nicht" . ZT::GRAY . "!");
							
						}
					} else {
						
						$sender->sendMessage("§cUsage: /gg set <name> <rang>");
						
					}
					
					
				}
				
				if (strtolower($args[0]) == "add") {
					if (!empty($args[1])) {
						if(!$groupfile->exists($args[1])) {
							$group = $args[1];
							$this->group->addGroup($group);
							$sender->sendMessage($this->prefix . TextFormat::GREEN . "Du hast die Gruppe " . TextFormat::GOLD . $group . TextFormat::GREEN . " Erfolgreich erstellt");
						} else {
							
							$sender->sendMessage($this->prefix . TextFormat::RED . "Es gibt den Rang " . TextFormat::GOLD . $args[1] . TextFormat::RED . " Bereits");
							
						}
					
					} else {
						
						$sender->sendMessage(ZT::RED . "Usage: /gg add <rang>");
						
					}
					
					
				} 
				if (strtolower($args[0]) == "help") {
					$sender->sendMessage($this->prefix . "-> /gg add <rang>");
					$sender->sendMessage($this->prefix . "-> /gg set <name> <rang>");
				}
			} else  {
				
				$sender->sendMessage($this->prefix . "-> /gg add <rang>");
				$sender->sendMessage($this->prefix . "-> /gg set <name> <rang>");
				
			}
			} else {
				
				$sender->sendMessage($this->prefix . ZT::RED . "Du benötigst OP");
				
			}
			
		}
		return true;
		
	}
	
	public function getGroup($name) {
		
		return $this->group->getGroup($name);
		
	}
	
}