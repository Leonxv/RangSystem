<?php

namespace zFloriq\Listeners;

use zFloriq\Main\Rang;
use zFloriq\Group\Group;

use pocketmine\event\player\PlayerJoinEvent;

use pocketmine\Player;
use pocketmine\event\Listener;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat;

use pocketmine\item\Item;

use pocketmine\scheduler\Task;

class PlayerJoinListener implements Listener {
	
	public function __construct(Rang $plugin) {
		
		$this->plugin = $plugin;
		
		$this->group = new Group($plugin);
		
	}
	
	public function onJoin(PlayerJoinEvent $event) {
		$player = $event->getPlayer();
		$name = $event->getPlayer()->getName();
		
		$playerfile = new Config(Rang::$pfad . "Players/" . strtolower($name) . ".yml", Config::YAML);
		
		$inv = $player->getInventory();
		
		$PlayerFile = new Config(Rang::$pfad . "Players/" . strtolower($name) . ".yml", Config::YAML);
		if ($playerfile->get("Group") == null) {
			$playerfile->set("Group", "Spieler");
			$playerfile->save();
		}
		
		if ($playerfile->get("Nick") == null) {
			$playerfile->set("Nick", "UNNICKED");
			$playerfile->save();
		}
		
		$playerfile->save();
		
		$player->setDisplayName((string)$this->group->getNameTag($name));
		$player->setNameTag((string)$this->group->getNameTag($name));
		
		$this->plugin->group->registerPlayer($name);
		
	}
	
}